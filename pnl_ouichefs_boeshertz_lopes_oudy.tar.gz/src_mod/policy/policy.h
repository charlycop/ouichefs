#ifndef _POLICY_H
#define _POLICY_H

typedef enum TypePolicy TypePolicy;
enum TypePolicy {tp_biggest, tp_oldest, tp_directory, tp_partition};

#endif	/* _POLICY_H */
