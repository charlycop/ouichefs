## Changement de politique de suppression

#### Plus vieux -> Plus gros

---

1. La commande "make" pour compiler le module policy.c

2. La commande "insmod policy.ko" pour inserer le moudle et donc changer la politique de netoyage de oldest a biggest

3. La commande "rmmod policy.ko" Pour remmmetre la politique de netoyage a odlest 


