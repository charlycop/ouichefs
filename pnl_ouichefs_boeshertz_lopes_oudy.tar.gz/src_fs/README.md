## OUICHEFS _ ajout de fonctionnalités

Informations complémentaire :

Politique par défaut : le plus vieux fichier.

---

Après compilation, deux modules sont créé :

- ouichefs.ko : fonctionnant sur linux 4.19.3 original

- ouichefs_sys.ko : incluant le syscall de la question 2.2, mais nécessitant de patcher le kernel.

---
